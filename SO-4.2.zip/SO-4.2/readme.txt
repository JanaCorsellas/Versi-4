Link al video: https://www.youtube.com/watch?v=nNs3Ypv84P4
-std=c99 `mysql_config --cflags --libs`